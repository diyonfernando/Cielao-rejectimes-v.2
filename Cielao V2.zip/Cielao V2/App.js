import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  FlatList,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';

const API_URL = 'https://6aa159b62703577aa1e393e8.mockapi.io/Field';
const COURSE_CACHE_KEY = '@cielao/course-cache-v1';
const SAVED_COURSES_KEY = '@cielao/saved-courses-v1';

const EMPTY_COURSE = {
  code: '', title: '', lecturer: '', time: '', room: '', progress: '0', description: '',
};

function normalizeCourse(course) {
  const recordId = course.id ?? course.Field ?? course.field;

  return {
    id: recordId == null ? '' : String(recordId),
    code: String(course.code || 'NO CODE'),
    title: String(course.title || course.name || 'Untitled course'),
    lecturer: String(course.lecturer || 'Not assigned'),
    time: String(course.time || 'Schedule not set'),
    room: String(course.room || 'Location not set'),
    progress: Math.min(100, Math.max(0, Number(course.progress) || 0)),
    description: String(course.description || 'No description has been added.'),
  };
}

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  if (!response.ok) {
    const responseText = await response.text();
    throw new Error(responseText || `Request failed with status ${response.status}`);
  }
  return response.status === 204 ? null : response.json();
}

function SplashScreen({ onFinish }) {
  const progress = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const animation = Animated.timing(progress, {
      toValue: 1, duration: 1800, useNativeDriver: false,
    });
    animation.start(({ finished }) => finished && onFinish());
    return () => animation.stop();
  }, [onFinish, progress]);

  return (
    <ImageBackground source={require('./assets/cielao-splash.jpg')} style={styles.splash} resizeMode="cover">
      <StatusBar hidden />
      <View style={styles.loadingArea}>
        <View style={styles.loadingTrack}>
          <Animated.View style={[styles.loadingFill, {
            width: progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
          }]} />
        </View>
      </View>
    </ImageBackground>
  );
}

function CielaoHeader() {
  return <View style={styles.cielaoHeader}><Text style={styles.cielaoText}>CIELAO</Text></View>;
}

function StatusMessage({ error, offline, onRetry }) {
  if (!error && !offline) return null;
  return (
    <View style={[styles.statusMessage, error ? styles.errorStatus : styles.offlineStatus]}>
      <View style={styles.statusCopy}>
        <Text style={styles.statusTitle}>{error ? 'Connection problem' : 'Offline copy'}</Text>
        <Text style={styles.statusText}>{error || 'Showing courses saved on this device.'}</Text>
      </View>
      <Pressable onPress={onRetry} style={styles.smallButton}><Text style={styles.smallButtonText}>RETRY</Text></Pressable>
    </View>
  );
}

function CourseCard({ course, onPress }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.courseCard, pressed && styles.coursePressed]}>
      <View style={styles.cardTop}>
        <Text style={styles.courseCode}>{course.code}</Text>
        <Text style={styles.courseProgress}>{course.progress}%</Text>
      </View>
      <Text style={styles.courseTitle}>{course.title}</Text>
      <Text style={styles.courseLecturer}>{course.lecturer}</Text>
      <Text style={styles.courseSchedule}>{course.time}</Text>
      <Text style={styles.courseSchedule}>{course.room}</Text>
      <View style={styles.cardBottom}>
        <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${course.progress}%` }]} /></View>
        <Text style={styles.viewCourse}>VIEW COURSE →</Text>
      </View>
    </Pressable>
  );
}

function BottomNavigation({ currentScreen, setCurrentScreen }) {
  const homeSelected = currentScreen === 'Home';
  const settingsSelected = currentScreen === 'Settings';
  return (
    <View style={styles.bottomNavigation}>
      <Pressable style={[styles.navButton, homeSelected && styles.navButtonActive]} onPress={() => setCurrentScreen('Home')}>
        <Text style={[styles.homeIcon, homeSelected ? styles.navBlue : styles.navWhite]}>⌂</Text>
        <Text style={[styles.navText, homeSelected ? styles.navBlue : styles.navWhite]}>Home</Text>
      </Pressable>
      <Pressable style={[styles.navButton, settingsSelected && styles.navButtonActive]} onPress={() => setCurrentScreen('Settings')}>
        <Text style={[styles.settingsIcon, settingsSelected ? styles.navBlue : styles.navWhite]}>⚙︎</Text>
        <Text style={[styles.navText, settingsSelected ? styles.navBlue : styles.navWhite]}>Settings</Text>
      </Pressable>
    </View>
  );
}

function HomeScreen({ courses, loading, refreshing, error, offline, openCourse, openCreate, refreshCourses, setCurrentScreen }) {
  const [searchText, setSearchText] = useState('');
  const [filterEnabled, setFilterEnabled] = useState(false);
  const filteredCourses = useMemo(() => {
    const query = searchText.trim().toLowerCase();
    return courses.filter((course) => {
      const matchesSearch = course.title.toLowerCase().includes(query)
        || course.code.toLowerCase().includes(query)
        || course.lecturer.toLowerCase().includes(query);
      return matchesSearch && (!filterEnabled || course.progress >= 70);
    });
  }, [courses, filterEnabled, searchText]);

  if (loading) {
    return (
      <SafeAreaView style={styles.centeredScreen}>
        <StatusBar barStyle="light-content" />
        <ActivityIndicator size="large" color="#4BC2B6" />
        <Text style={styles.loadingText}>Loading courses...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.homeScreen}>
      <StatusBar barStyle="light-content" />
      <FlatList
        data={filteredCourses}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.homeContent}
        refreshing={refreshing}
        onRefresh={refreshCourses}
        ListHeaderComponent={
          <View>
            <CielaoHeader />
            <View style={styles.welcomeRow}>
              <Text style={styles.welcomeText}>WELCOME BACK{`\n`}DIYON</Text>
              <Pressable onPress={() => setFilterEnabled((value) => !value)} style={[styles.filterButton, filterEnabled && styles.filterActive]}>
                <Text style={[styles.filterText, filterEnabled && styles.filterTextActive]}>{filterEnabled ? 'Filtered' : 'Filters'}</Text>
              </Pressable>
            </View>
            <StatusMessage error={error} offline={offline} onRetry={refreshCourses} />
            <TextInput value={searchText} onChangeText={setSearchText} placeholder="Search course, code or lecturer" placeholderTextColor="#777777" style={styles.searchInput} autoCapitalize="none" />
            <View style={styles.courseSectionHeader}>
              <View><Text style={styles.myCourses}>My Courses</Text><Text style={styles.courseCount}>{filteredCourses.length} course(s)</Text></View>
              <Pressable onPress={openCreate} style={styles.addButton}><Text style={styles.addButtonText}>＋ ADD</Text></Pressable>
            </View>
          </View>
        }
        renderItem={({ item }) => <CourseCard course={item} onPress={() => openCourse(item)} />}
        ListEmptyComponent={
          <View style={styles.noCourses}>
            <Text style={styles.noCoursesTitle}>{courses.length === 0 ? 'No courses yet' : 'No matches found'}</Text>
            <Text style={styles.noCoursesText}>{courses.length === 0 ? 'Add your first course to create a record in MockAPI.' : 'Try a different search or turn off the filter.'}</Text>
            {courses.length === 0 && <Pressable onPress={openCreate} style={styles.emptyAddButton}><Text style={styles.emptyAddButtonText}>ADD FIRST COURSE</Text></Pressable>}
          </View>
        }
      />
      <BottomNavigation currentScreen="Home" setCurrentScreen={setCurrentScreen} />
    </SafeAreaView>
  );
}

function DetailItem({ label, value }) {
  return <View style={styles.detailInformation}><Text style={styles.detailLabel}>{label}</Text><Text style={styles.detailValue}>{value}</Text></View>;
}

function DetailScreen({ course, saved, busy, goBack, onToggleSaved, onEdit, onDelete }) {
  return (
    <SafeAreaView style={styles.detailScreen}>
      <StatusBar barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.detailContainer}>
        <Pressable onPress={goBack} style={styles.backButton}><Text style={styles.backButtonText}>← BACK</Text></Pressable>
        <CielaoHeader />
        <View style={styles.detailWhiteCard}>
          <Text style={styles.detailCode}>{course.code}</Text>
          <Text style={styles.detailTitle}>{course.title}</Text>
          <Text style={styles.detailDescription}>{course.description}</Text>
          <DetailItem label="LECTURER" value={course.lecturer} />
          <DetailItem label="SCHEDULE" value={course.time} />
          <DetailItem label="LOCATION" value={course.room} />
          <DetailItem label="PROGRESS" value={`${course.progress}%`} />
          <Pressable onPress={onToggleSaved} style={[styles.saveButton, saved && styles.savedButton]}>
            <Text style={styles.saveButtonText}>{saved ? 'SAVED OFFLINE ✓' : 'SAVE OFFLINE'}</Text>
          </Pressable>
          <View style={styles.actionRow}>
            <Pressable disabled={busy} onPress={onEdit} style={[styles.actionButton, styles.editButton]}><Text style={styles.actionButtonText}>EDIT</Text></Pressable>
            <Pressable disabled={busy} onPress={onDelete} style={[styles.actionButton, styles.deleteButton, busy && styles.disabledButton]}>
              {busy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.actionButtonText}>DELETE</Text>}
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function FormField({ label, value, onChangeText, placeholder, keyboardType, multiline }) {
  return (
    <View style={styles.formGroup}>
      <Text style={styles.formLabel}>{label}</Text>
      <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#8A8A8A" keyboardType={keyboardType} multiline={multiline} style={[styles.formInput, multiline && styles.formTextArea]} />
    </View>
  );
}

function CourseFormScreen({ course, busy, error, onCancel, onSubmit }) {
  const [form, setForm] = useState(course ? { ...course, progress: String(course.progress) } : { ...EMPTY_COURSE });
  const [validationError, setValidationError] = useState('');
  const updateField = (field, value) => setForm((current) => ({ ...current, [field]: value }));
  const submit = () => {
    if (!form.code.trim() || !form.title.trim() || !form.lecturer.trim()) {
      setValidationError('Course code, title, and lecturer are required.'); return;
    }
    const progress = Number(form.progress);
    if (!Number.isFinite(progress) || progress < 0 || progress > 100) {
      setValidationError('Progress must be a number from 0 to 100.'); return;
    }
    setValidationError('');
    onSubmit({
      code: form.code.trim(), title: form.title.trim(), lecturer: form.lecturer.trim(),
      time: form.time.trim() || 'Schedule not set', room: form.room.trim() || 'Location not set',
      progress, description: form.description.trim() || 'No description has been added.',
    });
  };

  return (
    <SafeAreaView style={styles.formScreen}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView style={styles.flexOne} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.formContent} keyboardShouldPersistTaps="handled">
          <Pressable onPress={onCancel} style={styles.backButton}><Text style={styles.backButtonText}>← CANCEL</Text></Pressable>
          <CielaoHeader />
          <Text style={styles.formTitle}>{course ? 'EDIT COURSE' : 'ADD COURSE'}</Text>
          <View style={styles.formCard}>
            <FormField label="COURSE CODE *" value={form.code} onChangeText={(v) => updateField('code', v)} placeholder="CSI2114" />
            <FormField label="COURSE TITLE *" value={form.title} onChangeText={(v) => updateField('title', v)} placeholder="Mobile Application Development" />
            <FormField label="LECTURER *" value={form.lecturer} onChangeText={(v) => updateField('lecturer', v)} placeholder="Dr. Perera" />
            <FormField label="SCHEDULE" value={form.time} onChangeText={(v) => updateField('time', v)} placeholder="Monday • 9:00 AM" />
            <FormField label="LOCATION" value={form.room} onChangeText={(v) => updateField('room', v)} placeholder="Lab 03" />
            <FormField label="PROGRESS (0–100)" value={form.progress} onChangeText={(v) => updateField('progress', v)} placeholder="0" keyboardType="number-pad" />
            <FormField label="DESCRIPTION" value={form.description} onChangeText={(v) => updateField('description', v)} placeholder="What this course covers" multiline />
            {!!(validationError || error) && <Text style={styles.formError}>{validationError || error}</Text>}
            <Pressable disabled={busy} onPress={submit} style={[styles.submitButton, busy && styles.disabledButton]}>
              {busy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.submitButtonText}>{course ? 'UPDATE COURSE' : 'CREATE COURSE'}</Text>}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function SettingsScreen({ notifications, setNotifications, courseCount, savedCount, setCurrentScreen }) {
  return (
    <SafeAreaView style={styles.settingsScreen}>
      <StatusBar barStyle="light-content" />
      <ScrollView contentContainerStyle={styles.settingsPageContent}>
        <CielaoHeader /><Text style={styles.settingsTitle}>SETTINGS</Text>
        <View style={styles.settingsCard}><View style={styles.settingRow}><View style={styles.flexOne}><Text style={styles.settingName}>Notifications</Text><Text style={styles.settingDescription}>Receive course reminders</Text></View><Switch value={notifications} onValueChange={setNotifications} /></View></View>
        <View style={styles.settingsCard}><Text style={styles.settingName}>Data summary</Text><Text style={styles.settingDescription}>{courseCount} API course(s)</Text><Text style={styles.settingDescription}>{savedCount} course(s) marked for offline access</Text></View>
        <View style={styles.settingsCard}><Text style={styles.settingName}>About CIELAO</Text><Text style={styles.settingDescription}>CIELAO uses MockAPI for course management and AsyncStorage for offline persistence.</Text><Text style={styles.version}>Sprint 2 • Version 2.0</Text></View>
      </ScrollView>
      <BottomNavigation currentScreen="Settings" setCurrentScreen={setCurrentScreen} />
    </SafeAreaView>
  );
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('Splash');
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [savedCourseIds, setSavedCourseIds] = useState([]);
  const [notifications, setNotifications] = useState(true);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [offline, setOffline] = useState(false);

  const cacheCourses = useCallback(async (nextCourses) => {
    await AsyncStorage.setItem(COURSE_CACHE_KEY, JSON.stringify(nextCourses));
  }, []);

  const loadCourses = useCallback(async (isRefresh = false) => {
    isRefresh ? setRefreshing(true) : setLoading(true);
    setError('');
    try {
      const result = await apiRequest(API_URL);
      const normalized = Array.isArray(result) ? result.map(normalizeCourse) : [];
      setCourses(normalized); await cacheCourses(normalized); setOffline(false);
    } catch (requestError) {
      try {
        const cached = await AsyncStorage.getItem(COURSE_CACHE_KEY);
        const parsed = cached ? JSON.parse(cached) : [];
        setCourses(Array.isArray(parsed) ? parsed.map(normalizeCourse) : []);
        setOffline(Boolean(cached));
        setError(cached ? '' : 'Unable to reach MockAPI and no offline data is available.');
      } catch {
        setError('Unable to load online or offline course data.');
      }
    } finally { setLoading(false); setRefreshing(false); }
  }, [cacheCourses]);

  useEffect(() => {
    const initialize = async () => {
      try {
        const saved = await AsyncStorage.getItem(SAVED_COURSES_KEY);
        setSavedCourseIds(saved ? JSON.parse(saved) : []);
      } catch { setSavedCourseIds([]); }
      await loadCourses();
    };
    initialize();
  }, [loadCourses]);

  const finishSplash = useCallback(() => setCurrentScreen('Home'), []);

  const createCourse = async (payload) => {
    setBusy(true); setError('');
    try {
      const created = normalizeCourse(await apiRequest(API_URL, { method: 'POST', body: JSON.stringify(payload) }));
      const nextCourses = [created, ...courses];
      setCourses(nextCourses); await cacheCourses(nextCourses); setSelectedCourse(created); setOffline(false); setCurrentScreen('Detail');
    } catch (requestError) { setError('Course could not be created. Check the connection and try again.'); }
    finally { setBusy(false); }
  };

  const updateCourse = async (payload) => {
    if (!selectedCourse) return;
    setBusy(true); setError('');
    try {
      const updated = normalizeCourse(await apiRequest(`${API_URL}/${selectedCourse.id}`, { method: 'PUT', body: JSON.stringify(payload) }));
      const nextCourses = courses.map((course) => course.id === updated.id ? updated : course);
      setCourses(nextCourses); setSelectedCourse(updated); await cacheCourses(nextCourses); setOffline(false); setCurrentScreen('Detail');
    } catch (requestError) { setError('Course could not be updated. Check the connection and try again.'); }
    finally { setBusy(false); }
  };

  const confirmDelete = () => {
    if (!selectedCourse) return;
    Alert.alert('Delete course?', `${selectedCourse.code} will be permanently removed from MockAPI.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        setBusy(true); setError('');
        try {
          await apiRequest(`${API_URL}/${selectedCourse.id}`, { method: 'DELETE' });
          const nextCourses = courses.filter((course) => course.id !== selectedCourse.id);
          const nextSaved = savedCourseIds.filter((id) => id !== selectedCourse.id);
          setCourses(nextCourses); setSavedCourseIds(nextSaved);
          await Promise.all([cacheCourses(nextCourses), AsyncStorage.setItem(SAVED_COURSES_KEY, JSON.stringify(nextSaved))]);
          setSelectedCourse(null); setCurrentScreen('Home');
        } catch (requestError) {
          Alert.alert('Delete failed', requestError.message || 'Check the connection and try again.');
        }
        finally { setBusy(false); }
      } },
    ]);
  };

  const toggleSaved = async () => {
    if (!selectedCourse) return;
    const nextSaved = savedCourseIds.includes(selectedCourse.id)
      ? savedCourseIds.filter((id) => id !== selectedCourse.id)
      : [...savedCourseIds, selectedCourse.id];
    setSavedCourseIds(nextSaved);
    await AsyncStorage.setItem(SAVED_COURSES_KEY, JSON.stringify(nextSaved));
  };

  if (currentScreen === 'Splash') return <SplashScreen onFinish={finishSplash} />;
  if (currentScreen === 'Form') return <CourseFormScreen course={selectedCourse} busy={busy} error={error} onCancel={() => setCurrentScreen(selectedCourse ? 'Detail' : 'Home')} onSubmit={selectedCourse ? updateCourse : createCourse} />;
  if (currentScreen === 'Detail' && selectedCourse) return <DetailScreen course={selectedCourse} saved={savedCourseIds.includes(selectedCourse.id)} busy={busy} goBack={() => setCurrentScreen('Home')} onToggleSaved={toggleSaved} onEdit={() => { setError(''); setCurrentScreen('Form'); }} onDelete={confirmDelete} />;
  if (currentScreen === 'Settings') return <SettingsScreen notifications={notifications} setNotifications={setNotifications} courseCount={courses.length} savedCount={savedCourseIds.length} setCurrentScreen={setCurrentScreen} />;
  return <HomeScreen courses={courses} loading={loading} refreshing={refreshing} error={error} offline={offline} refreshCourses={() => loadCourses(true)} openCreate={() => { setSelectedCourse(null); setError(''); setCurrentScreen('Form'); }} openCourse={(course) => { setSelectedCourse(course); setCurrentScreen('Detail'); }} setCurrentScreen={setCurrentScreen} />;
}

const styles = StyleSheet.create({
  flexOne: { flex: 1 }, splash: { flex: 1, width: '100%', height: '100%' },
  loadingArea: { position: 'absolute', top: '62%', width: '58%', alignSelf: 'center' },
  loadingTrack: { height: 5, width: '100%', borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.25)', overflow: 'hidden' },
  loadingFill: { height: '100%', backgroundColor: '#FFFFFF', borderRadius: 20 },
  homeScreen: { flex: 1, backgroundColor: '#000000' }, centeredScreen: { flex: 1, backgroundColor: '#000000', alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: '#FFFFFF', fontSize: 15, fontWeight: '600', marginTop: 14 },
  homeContent: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 150 },
  cielaoHeader: { width: '100%', height: 82, backgroundColor: '#104F49', borderRadius: 50, alignItems: 'center', justifyContent: 'center', marginTop: 5, marginBottom: 25 },
  cielaoText: { color: '#FFFFFF', fontWeight: '700', fontSize: 41, letterSpacing: 1 }, welcomeRow: { position: 'relative', marginBottom: 18 },
  welcomeText: { color: '#FFFFFF', fontWeight: '700', fontSize: 32, lineHeight: 38 },
  filterButton: { position: 'absolute', right: 0, bottom: 0, borderWidth: 2, borderColor: '#4BC2B6', borderRadius: 30, paddingHorizontal: 12, paddingVertical: 4 },
  filterActive: { backgroundColor: '#104F49' }, filterText: { fontWeight: '600', color: '#4BC2B6', fontSize: 14 }, filterTextActive: { color: '#FFFFFF' },
  statusMessage: { borderRadius: 14, padding: 14, marginBottom: 14, flexDirection: 'row', alignItems: 'center' }, errorStatus: { backgroundColor: '#4B1717' }, offlineStatus: { backgroundColor: '#203A37' },
  statusCopy: { flex: 1, paddingRight: 10 }, statusTitle: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 }, statusText: { color: '#E6E6E6', fontSize: 12, lineHeight: 17, marginTop: 2 },
  smallButton: { borderWidth: 1, borderColor: '#FFFFFF', borderRadius: 20, paddingHorizontal: 11, paddingVertical: 7 }, smallButtonText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  searchInput: { width: '100%', height: 53, backgroundColor: '#FFFFFF', color: '#000000', fontSize: 16, borderRadius: 13, paddingHorizontal: 18, marginBottom: 15 },
  courseSectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }, myCourses: { color: '#FFFFFF', fontWeight: '700', fontSize: 30 }, courseCount: { color: '#9C9C9C', fontSize: 12, marginTop: 2 },
  addButton: { backgroundColor: '#104F49', borderRadius: 24, paddingHorizontal: 15, paddingVertical: 11 }, addButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 12 },
  courseCard: { backgroundColor: '#FFFFFF', borderRadius: 22, minHeight: 205, padding: 22, marginBottom: 18, justifyContent: 'space-between' }, coursePressed: { opacity: 0.85, transform: [{ scale: 0.99 }] },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, courseCode: { color: '#104F49', fontWeight: '700', fontSize: 14, letterSpacing: 1 }, courseProgress: { color: '#104F49', fontWeight: '700', fontSize: 16 },
  courseTitle: { color: '#000000', fontWeight: '700', fontSize: 24, lineHeight: 29, marginTop: 8 }, courseLecturer: { color: '#555555', fontWeight: '500', fontSize: 14, marginTop: 7 }, courseSchedule: { color: '#777777', fontSize: 13, marginTop: 2 },
  cardBottom: { marginTop: 16 }, progressTrack: { width: '100%', height: 6, backgroundColor: '#D9D9D9', borderRadius: 20, overflow: 'hidden' }, progressFill: { height: '100%', backgroundColor: '#104F49' },
  viewCourse: { color: '#104F49', fontWeight: '700', fontSize: 11, textAlign: 'right', marginTop: 11, letterSpacing: 0.6 },
  bottomNavigation: { position: 'absolute', bottom: 20, alignSelf: 'center', width: 230, height: 78, flexDirection: 'row', backgroundColor: 'rgba(100,100,100,0.92)', borderRadius: 40, borderWidth: 1, borderColor: 'rgba(255,255,255,0.45)', overflow: 'hidden', elevation: 15 },
  navButton: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 40 }, navButtonActive: { backgroundColor: 'rgba(255,255,255,0.22)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)' }, navText: { fontWeight: '600', fontSize: 11, marginTop: 1 }, homeIcon: { fontSize: 33, lineHeight: 34 }, settingsIcon: { fontSize: 28, lineHeight: 31 }, navBlue: { color: '#4BC2B6' }, navWhite: { color: '#FFFFFF' },
  noCourses: { backgroundColor: '#FFFFFF', borderRadius: 22, padding: 35, alignItems: 'center' }, noCoursesTitle: { color: '#000000', fontWeight: '700', fontSize: 20 }, noCoursesText: { color: '#666666', marginTop: 7, textAlign: 'center', lineHeight: 19 },
  emptyAddButton: { backgroundColor: '#104F49', paddingHorizontal: 18, paddingVertical: 12, borderRadius: 22, marginTop: 18 }, emptyAddButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 12 },
  detailScreen: { flex: 1, backgroundColor: '#000000' }, detailContainer: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 40 }, backButton: { marginBottom: 10, alignSelf: 'flex-start', paddingVertical: 5 }, backButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },
  detailWhiteCard: { backgroundColor: '#FFFFFF', borderRadius: 25, padding: 23 }, detailCode: { color: '#104F49', fontWeight: '700', fontSize: 15 }, detailTitle: { color: '#000000', fontWeight: '700', fontSize: 28, lineHeight: 34, marginTop: 10 }, detailDescription: { color: '#666666', fontSize: 14, lineHeight: 21, marginTop: 12, marginBottom: 15 },
  detailInformation: { backgroundColor: '#F3F3F3', padding: 14, borderRadius: 12, marginTop: 9 }, detailLabel: { color: '#104F49', fontWeight: '700', fontSize: 10, letterSpacing: 1 }, detailValue: { color: '#000000', fontWeight: '500', fontSize: 15, marginTop: 4 },
  saveButton: { backgroundColor: '#104F49', borderRadius: 30, paddingVertical: 15, alignItems: 'center', marginTop: 22 }, savedButton: { backgroundColor: '#2468A2' }, saveButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },
  actionRow: { flexDirection: 'row', marginTop: 12 }, actionButton: { flex: 1, borderRadius: 24, paddingVertical: 14, alignItems: 'center' }, editButton: { backgroundColor: '#222222', marginRight: 6 }, deleteButton: { backgroundColor: '#A62A2A', marginLeft: 6 }, actionButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 13 }, disabledButton: { opacity: 0.55 },
  formScreen: { flex: 1, backgroundColor: '#000000' }, formContent: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 50 }, formTitle: { color: '#FFFFFF', fontSize: 31, fontWeight: '700', marginBottom: 17 }, formCard: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 20 },
  formGroup: { marginBottom: 14 }, formLabel: { color: '#104F49', fontWeight: '700', fontSize: 11, letterSpacing: 0.7, marginBottom: 6 }, formInput: { backgroundColor: '#F1F1F1', color: '#000000', borderRadius: 12, minHeight: 49, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15 }, formTextArea: { height: 105, textAlignVertical: 'top' }, formError: { color: '#A62A2A', fontWeight: '600', fontSize: 13, lineHeight: 18, marginBottom: 12 }, submitButton: { backgroundColor: '#104F49', borderRadius: 28, paddingVertical: 16, alignItems: 'center', marginTop: 4 }, submitButtonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },
  settingsScreen: { flex: 1, backgroundColor: '#000000' }, settingsPageContent: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 130 }, settingsTitle: { color: '#FFFFFF', fontWeight: '700', fontSize: 34, marginBottom: 20 }, settingsCard: { backgroundColor: '#FFFFFF', borderRadius: 22, padding: 20, marginBottom: 16 }, settingRow: { flexDirection: 'row', alignItems: 'center' }, settingName: { color: '#000000', fontWeight: '700', fontSize: 18 }, settingDescription: { color: '#666666', fontSize: 13, lineHeight: 19, marginTop: 5 }, version: { color: '#104F49', fontWeight: '600', marginTop: 15 },
});
