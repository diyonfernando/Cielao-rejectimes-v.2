import React, { useEffect, useRef } from 'react';
import {
  Animated,
  ImageBackground,
  StyleSheet,
  View,
} from 'react-native';

export default function SplashScreen({ onFinish }) {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animation = Animated.timing(progress, {
      toValue: 1,
      duration: 2500,
      useNativeDriver: false,
    });

    animation.start(({ finished }) => {
      if (finished) {
        setTimeout(() => {
          onFinish();
        }, 250);
      }
    });

    return () => animation.stop();
  }, [onFinish, progress]);

  const loadingWidth = progress.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 260],
  });

  return (
    <ImageBackground
      source={require('../assets/cielao-splash.jpg')}
      style={styles.splashScreen}
      resizeMode="cover"
    >
      <View style={styles.loadingContainer}>
        <View style={styles.loadingTrack}>
          <Animated.View
            style={[
              styles.loadingBar,
              { width: loadingWidth },
            ]}
          />
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  splashScreen: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  loadingContainer: {
    position: 'absolute',
    top: '62%',
    alignSelf: 'center',
    width: 260,
  },
  loadingTrack: {
    width: 260,
    height: 5,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  loadingBar: {
    height: 5,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
  },
});
