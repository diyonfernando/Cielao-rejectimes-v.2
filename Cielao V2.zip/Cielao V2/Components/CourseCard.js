import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function CourseCard({ course, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Text style={styles.code}>{course.code}</Text>
      <Text style={styles.title}>{course.title}</Text>
      <Text style={styles.info}>Lecturer: {course.lecturer}</Text>
      <Text style={styles.info}>Room: {course.room}</Text>
      <Text style={styles.info}>Time: {course.time}</Text>

      <View style={styles.progressBar}>
        <View
          style={[
            styles.progressFill,
            { width: `${course.progress}%` }
          ]}
        />
      </View>

      <Text style={styles.progressText}>
        Progress: {course.progress}%
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 16,
    marginVertical: 10,
    marginHorizontal: 15,
    borderRadius: 12,
    elevation: 3,
  },
  code: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0057D9',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 5,
  },
  info: {
    marginTop: 3,
    color: '#555',
  },
  progressBar: {
    marginTop: 10,
    backgroundColor: '#ddd',
    height: 8,
    borderRadius: 5,
  },
  progressFill: {
    height: 8,
    backgroundColor: '#22C55E',
    borderRadius: 5,
  },
  progressText: {
    marginTop: 8,
    fontWeight: 'bold',
  },
});